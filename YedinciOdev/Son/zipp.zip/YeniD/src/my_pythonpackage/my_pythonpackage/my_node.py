def main():
    print('Hi from my_pythonpackage.')


if __name__ == '__main__':
    main()
